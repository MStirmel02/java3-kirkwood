create
    definer = wetaanqwil@`%` procedure sp_get_user(IN p_email varchar(255))
BEGIN
    SELECT id, email, password, language, status, created_at, last_logged_in, updated_at, attempts
    FROM user
    WHERE email = p_email;
END;

