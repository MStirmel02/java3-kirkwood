create
    definer = wetaanqwil@`%` procedure sp_get_object()
BEGIN
    SELECT *
    FROM Object
    ;
    END;

