create
    definer = wetaanqwil@`%` procedure sp_create_object(IN p_objectid varchar(50), IN p_objecttype varchar(50),
                                                        IN p_rightascension varchar(50), IN p_declination varchar(50))
BEGIN
    INSERT INTO Object(
                           ObjectID
                      ,	ObjectType
                      ,	RightAscension
                      ,	Declination
    ) VALUES (
                  p_objectid
             ,	p_objecttype
             ,	p_rightascension
             ,	p_declination
             );
END;

