create
    definer = wetaanqwil@`%` procedure sp_set_status(IN p_status enum ('inactive', 'active', 'locked'),
                                                     IN p_email varchar(255))
BEGIN
    UPDATE user
    SET status = p_status
    WHERE email = p_email;

END;

