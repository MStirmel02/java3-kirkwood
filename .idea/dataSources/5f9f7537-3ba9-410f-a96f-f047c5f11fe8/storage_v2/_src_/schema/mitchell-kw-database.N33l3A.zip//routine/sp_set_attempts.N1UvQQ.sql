create
    definer = wetaanqwil@`%` procedure sp_set_attempts(IN p_attempts int, IN p_email varchar(255))
BEGIN
    UPDATE user
        SET attempts = p_attempts
    WHERE email = p_email;
END;

