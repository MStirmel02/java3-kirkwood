create
    definer = wetaanqwil@`%` procedure sp_view_channel_messages(IN p_ChannelID varchar(255))
    comment 'Returns all the messages from the selected channel.'
BEGIN

	SELECT UserID, Content, TimeSent
    FROM messages
    WHERE ChannelID = p_ChannelID
    ORDER BY TimeSent DESC;
    
END;

