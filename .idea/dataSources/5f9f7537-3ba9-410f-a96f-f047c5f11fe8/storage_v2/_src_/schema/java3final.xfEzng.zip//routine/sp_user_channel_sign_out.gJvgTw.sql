create
    definer = wetaanqwil@`%` procedure sp_user_channel_sign_out(IN p_UserID varchar(50), IN p_ChannelID varchar(255))
    comment 'Tries to log out of a channel'
BEGIN
	
    DELETE FROM UserChannels
	WHERE p_ChannelID = ChannelID AND p_UserID = UserID

;
END;

