create
    definer = wetaanqwil@`%` procedure sp_create_user(IN p_UserID varchar(50), IN p_PasswordHash varchar(255),
                                                      IN p_Email varchar(255)) comment 'Creates a user'
BEGIN

	INSERT INTO Users 
    VALUES (p_UserID, p_PasswordHash, p_Email, DEFAULT, DEFAULT);
	
END;

