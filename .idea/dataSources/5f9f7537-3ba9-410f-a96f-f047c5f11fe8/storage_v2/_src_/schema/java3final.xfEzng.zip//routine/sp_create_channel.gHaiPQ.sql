create
    definer = wetaanqwil@`%` procedure sp_create_channel(IN p_UserID varchar(50), IN p_PasswordHash varchar(255),
                                                         IN p_ChannelID varchar(255))
    comment 'Creates a channel, and assigns the user who created it to the channel with the appropriate permissions.'
BEGIN

	INSERT INTO channels
    VALUES (p_ChannelID, 1, p_PasswordHash, DEFAULT);
    
    INSERT INTO userchannels 
    VALUES (p_ChannelID, p_UserID, 'Creator');
    
END;

