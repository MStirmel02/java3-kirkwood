create
    definer = wetaanqwil@`%` procedure sp_user_sign_in(IN p_UserID varchar(50), IN p_PasswordHash varchar(255))
    comment 'Searches for a combination of the two, if none found, the user has inputted one wrong and does not get logged in.'
BEGIN

	SELECT COUNT(UserID)
    FROM users
    WHERE UserID = p_UserID AND PasswordHash = p_PasswordHash 
;
END;

