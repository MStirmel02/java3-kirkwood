create
    definer = wetaanqwil@`%` procedure sp_create_message(IN p_UserID varchar(50), IN p_ChannelID varchar(255),
                                                         IN p_Content text)
    comment 'Creates a message in the specified channel by the creating user.'
BEGIN

	INSERT INTO messages
    VALUES (DEFAULT, p_ChannelID, p_UserID, p_Content, DEFAULT);
    
END;

