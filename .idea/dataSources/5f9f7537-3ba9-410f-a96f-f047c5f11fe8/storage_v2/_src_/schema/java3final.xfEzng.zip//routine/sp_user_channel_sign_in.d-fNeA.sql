create
    definer = wetaanqwil@`%` procedure sp_user_channel_sign_in(IN p_UserID varchar(50), IN p_ChannelID varchar(255),
                                                               IN p_PasswordHash varchar(255))
    comment 'Tries to log in to a channel, if successful, the user will be added to the channel where the channelID and passwordhash match'
BEGIN
	

    
    DECLARE ChannelCount INT;

	SELECT COUNT(ChannelID) INTO ChannelCount
    FROM Channels
    WHERE p_ChannelID = ChannelID AND ChannelHash = p_PasswordHash;
    
    IF ChannelCount = 1 THEN
		INSERT INTO UserChannels
		VALUES(p_ChannelID, p_UserID, 'User');
    END IF;
    
	SELECT COUNT(ChannelID) AS 'Count'
    FROM Channels
    WHERE p_ChannelID = ChannelID AND ChannelHash = p_PasswordHash

;
END;

