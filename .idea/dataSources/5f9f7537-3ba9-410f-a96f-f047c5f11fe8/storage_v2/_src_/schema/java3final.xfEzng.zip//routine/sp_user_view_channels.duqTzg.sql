create
    definer = wetaanqwil@`%` procedure sp_user_view_channels(IN p_UserID varchar(50))
    comment 'Searches for the channels that the user is currently in. Also returns the role the user has in each channel'
BEGIN

	SELECT ChannelID, RoleID
    FROM UserChannels
    WHERE UserID = p_UserID
;
END;

